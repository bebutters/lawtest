Instructions for running environment:

Python written in 3.6 and Should be compatible with any 3.x version.
It is recommended to have Python on the PATH for windows.

Relies on Bottle Package. Recommended installation is via pip:
	'pip3 install bottle' in cmd, without quotes